# String-Algorithms-UI
 User interface to test and visualize the implementation of the string algorithms: Z, Manacher and LCS as well as the Trie data structure.
